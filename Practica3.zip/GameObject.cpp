#include "GameObject.h"
#include "Game.h"

GameObject::GameObject(Game *g)
{
	game = g;
}


GameObject::~GameObject()
{
}


